-- ================================================================
-- db_skincare_full.sql  —  Complete database for all 4 modules
-- Import this ONE file into phpMyAdmin.
--
-- Tables:
--   product         → Module 1 (Product Management)
--   tbl_supplier    → Module 2 (Supplier Management)
--   orders          → Module 3 (Sales & POS)
--   orderdetails    → Module 3 (Sales & POS)
--   products        → Module 4 (Reporting — stock alerts)
--   sales           → Module 4 (Reporting — sales data)
--   archived_reports→ Module 4 (Reporting — exported files)
-- ================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `db_skincare`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `db_skincare`;

-- ----------------------------------------------------------------
-- MODULE 1: Product Management
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `product` (
  `product_id`   varchar(10)   NOT NULL,
  `product_name` varchar(100)  NOT NULL,
  `brand`        varchar(50)   NOT NULL,
  `category`     varchar(50)   NOT NULL,
  `skin_type`    varchar(50)   NOT NULL,
  `price`        decimal(10,2) NOT NULL,
  `stock`        int(11)       NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `product` VALUES
  ('P001','Hydrating Cleanser','CeraVe',      'Cleanser', 'Oily',        40.00, 120),
  ('P002','Niacinamide Serum', 'The Ordinary','Serum',    'Combination', 59.00,  50),
  ('P003','Vitamin C Serum',   'Garnier',     'Serum',    'Oily',        45.00,  20),
  ('P004','Alia Sunscreen',    'Sunscreen',   'Sunscreen','Normal',      30.00,  10)
ON DUPLICATE KEY UPDATE product_id = product_id;

-- ----------------------------------------------------------------
-- MODULE 2: Supplier Management
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id`       varchar(50)  NOT NULL,
  `name`     varchar(100) NOT NULL,
  `reg_no`   varchar(50)  NOT NULL,
  `email`    varchar(100) NOT NULL,
  `category` varchar(50)  NOT NULL,
  `status`   varchar(30)  DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_supplier` VALUES
  ('SUP1','Torriden', '01','torriden@gmail.com', 'Body',   'Active'),
  ('SUP2','Cerave',   '02','cera@gnail.com',     'Body',   'Active'),
  ('SUP3','Skintific','03','skintific@gmail.com','Facial','Active'),
  ('SUP4','Glad2Glow','04','glad2glow@gmail.com','Facial','Active')
ON DUPLICATE KEY UPDATE id = id;

-- ----------------------------------------------------------------
-- MODULE 3: Sales & POS
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id`       int(11)       NOT NULL AUTO_INCREMENT,
  `order_date`     datetime      DEFAULT current_timestamp(),
  `total_amount`   decimal(10,2) NOT NULL,
  `payment_method` varchar(50)   NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `orders` VALUES
  (1,'2026-06-23 03:08:29',408.00,'Cash'),
  (2,'2026-06-23 03:10:00',255.00,'Card')
ON DUPLICATE KEY UPDATE order_id = order_id;

CREATE TABLE IF NOT EXISTS `orderdetails` (
  `detail_id`    int(11)       NOT NULL AUTO_INCREMENT,
  `order_id`     int(11)       DEFAULT NULL,
  `product_id`   int(11)       DEFAULT NULL,
  `product_name` varchar(100)  DEFAULT NULL,
  `quantity`     int(11)       NOT NULL,
  `subtotal`     decimal(10,2) NOT NULL,
  PRIMARY KEY (`detail_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `orderdetails` VALUES
  (1,1,101,'Sample Product 101',16,408.00),
  (2,2,102,'Sample Product 102',10,255.00)
ON DUPLICATE KEY UPDATE detail_id = detail_id;

-- ----------------------------------------------------------------
-- MODULE 4: Reporting & Analytics
-- (products + sales mirror Module 1 data for analytics queries)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `product_id`      varchar(20)  NOT NULL,
  `product_name`    varchar(100) NOT NULL,
  `category`        varchar(50)  DEFAULT NULL,
  `quantity`        int(11)      DEFAULT 0,
  `alert_threshold` int(11)      DEFAULT 5,
  `supplier_name`   varchar(100) DEFAULT NULL,
  `price`           varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` VALUES
  ('P001','Hydrating Cleanser','Skin Care',120, 5,'Cerave',    'RM 40.00'),
  ('P002','Niacinamide Serum', 'Skin Care', 50, 5,'BeautyCorp','RM 59.00'),
  ('P003','Vitamin C Serum',   'Skin Care', 20,10,'BeautyCorp','RM 45.00'),
  ('P004','Alia Sunscreen',    'Skin Care', 10,10,'BeautyCorp','RM 30.00')
ON DUPLICATE KEY UPDATE product_id = product_id;

CREATE TABLE IF NOT EXISTS `sales` (
  `sale_id`       int(11)       NOT NULL AUTO_INCREMENT,
  `product_id`    varchar(20)   DEFAULT NULL,
  `sale_date`     date          DEFAULT NULL,
  `quantity_sold` int(11)       DEFAULT NULL,
  `total_amount`  decimal(10,2) DEFAULT NULL,
  `profit`        decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products`(`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sales` VALUES
  (1,'P001','2026-06-17',1,3500.00,500.00),
  (2,'P002','2026-06-17',2, 400.00,100.00)
ON DUPLICATE KEY UPDATE sale_id = sale_id;

CREATE TABLE IF NOT EXISTS `archived_reports` (
  `id`          int(11)      NOT NULL AUTO_INCREMENT,
  `report_id`   varchar(50)  DEFAULT NULL,
  `file_path`   varchar(255) DEFAULT NULL,
  `export_date` date         DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `archived_reports` VALUES
  (1,'RPT-1781699158978','Archived_Reports/SalesReport_20260617_202559.csv','2026-06-17'),
  (2,'RPT-1782115351316','Archived_Reports/SalesReport_20260622_160326.csv','2026-06-22')
ON DUPLICATE KEY UPDATE id = id;

COMMIT;
