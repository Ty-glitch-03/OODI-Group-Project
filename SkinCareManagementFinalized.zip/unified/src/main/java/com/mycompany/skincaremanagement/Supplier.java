/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;

/**
 *
 * @author ASUS
 */
public class Supplier {
     private String id;
    private String name;
    private String regNo;
    private String email;
    private String category;
    private String status;
    
    public Supplier(String id, String name, String regNo, String email, String category, String status) {
        this.id = id;
        this.name = name;
        this.regNo = regNo;
        this.email = email;
        this.category = category;
        this.status = status;   
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRegNo() { return regNo; }
    public void setRegNo(String regNo) { this.regNo = regNo; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
}


