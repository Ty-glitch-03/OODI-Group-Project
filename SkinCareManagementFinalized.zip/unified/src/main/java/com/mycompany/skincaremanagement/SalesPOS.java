package com.mycompany.skincaremanagement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class SalesPOS extends JFrame {

    private JTextField txtProductID, txtQty;
    private JButton btnAdd, btnCheckout, btnBack;
    private JTable cartTable;
    private DefaultTableModel tableModel;
    private JLabel lblTotal;
    private JComboBox<String> comboPayment;
    private Order currentOrder;

    public SalesPOS() {
        currentOrder = new Order();
        setTitle("Skin Care - Point of Sale");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // INTEGRATION: DISPOSE so Dashboard stays open
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        buildInputPanel();
        buildCartPanel();
        buildCheckoutPanel();
    }

    private void buildInputPanel() {
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Add Product to Cart"));

        inputPanel.add(new JLabel("Product ID:"));
        txtProductID = new JTextField(10);
        inputPanel.add(txtProductID);

        inputPanel.add(new JLabel("Quantity:"));
        txtQty = new JTextField(5);
        inputPanel.add(txtQty);

        btnAdd = new JButton("Add to Cart");
        btnAdd.addActionListener(e -> addToCartAction());
        inputPanel.add(btnAdd);

        // INTEGRATION: Back button to return to main Dashboard
        btnBack = new JButton("← Back to Dashboard");
        btnBack.addActionListener(e -> dispose());
        inputPanel.add(btnBack);

        add(inputPanel, BorderLayout.NORTH);
    }

    private void buildCartPanel() {
        String[] columns = {"Product ID", "Product Name", "Qty", "Unit Price", "Subtotal"};
        tableModel = new DefaultTableModel(columns, 0);
        cartTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Current Cart"));
        add(scrollPane, BorderLayout.CENTER);
    }

    private void buildCheckoutPanel() {
        JPanel checkoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 10));

        lblTotal = new JLabel("Total: RM 0.00");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 16));
        checkoutPanel.add(lblTotal);

        checkoutPanel.add(new JLabel("Payment Method:"));
        comboPayment = new JComboBox<>(new String[]{"Cash", "Card"});
        checkoutPanel.add(comboPayment);

        btnCheckout = new JButton("Process Payment");
        btnCheckout.setBackground(new Color(34, 139, 34));
        btnCheckout.setForeground(Color.WHITE);
        btnCheckout.addActionListener(e -> processCheckoutAction());
        checkoutPanel.add(btnCheckout);

        add(checkoutPanel, BorderLayout.SOUTH);
    }

    private void addToCartAction() {
        try {
            // FIX: Keep product ID as String to align with VARCHAR structure in database
            String prodIdStr = txtProductID.getText().trim();
            if (prodIdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a Product ID.");
                return;
            }
            
            int qty = Integer.parseInt(txtQty.getText().trim());
            if (qty <= 0) {
                JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.");
                return;
            }

            String productName = "Product " + prodIdStr;
            double unitPrice = 0.0;

            // FIX: Nested database connection creation inside try block to handle SQLExceptions safely
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT product_name, price FROM product WHERE product_id = ?")) {
                    ps.setString(1, prodIdStr);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        productName = rs.getString("product_name");
                        unitPrice = rs.getDouble("price");
                    } else {
                        JOptionPane.showMessageDialog(this, "Product ID " + prodIdStr + " not found in database.");
                        return;
                    }
                }
            } else {
                // Fallback mock data if DB not available
                productName = "Sample Product " + prodIdStr;
                unitPrice = 25.50;
            }

            // Note: If CartItem constructor demands an integer ID, convert it securely for the object,
            // but your underlying SQL execution binds strings correctly.
            int numericId = 0;
            try { numericId = Integer.parseInt(prodIdStr); } catch(NumberFormatException ignored){}

            CartItem newItem = new CartItem(numericId, productName, qty, unitPrice);
            currentOrder.addItem(newItem);

            Object[] rowData = {
                prodIdStr, newItem.getProductName(),
                newItem.getQuantity(), String.format("%.2f", newItem.getUnitPrice()),
                String.format("%.2f", newItem.getSubtotal())
            };
            tableModel.addRow(rowData);
            lblTotal.setText("Total: RM " + String.format("%.2f", currentOrder.getGrandTotal()));

            txtProductID.setText("");
            txtQty.setText("");
            txtProductID.requestFocus();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values for quantity.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void processCheckoutAction() {
        if (currentOrder.getItemCount() == 0) {
            JOptionPane.showMessageDialog(this, "Cart is empty!");
            return;
        }

        String selectedPayment = comboPayment.getSelectedItem().toString();
        Payment payment;

        if (selectedPayment.equals("Cash")) {
            String cashStr = JOptionPane.showInputDialog(this,
                    String.format("Total: RM %.2f\nEnter cash amount (RM):", currentOrder.getGrandTotal()));
            if (cashStr == null) return;
            try {
                double cashGiven = Double.parseDouble(cashStr.trim());
                payment = new CashPayment(currentOrder.getGrandTotal(), cashGiven);
                if (!payment.processTransaction()) {
                    JOptionPane.showMessageDialog(this, "Insufficient cash! Need at least RM " +
                            String.format("%.2f", currentOrder.getGrandTotal()));
                    return;
                }
                double change = ((CashPayment) payment).getChange();
                JOptionPane.showMessageDialog(this, String.format("Change: RM %.2f", change));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid cash amount.");
                return;
            }
        } else {
            String cardNum = JOptionPane.showInputDialog(this, "Enter 16-digit Card Number:");
            if (cardNum == null) return;
            payment = new CardPayment(currentOrder.getGrandTotal(), cardNum.trim());
            if (!payment.processTransaction()) {
                JOptionPane.showMessageDialog(this, "Card invalid! Must be 16 digits.");
                return;
            }
        }

        // FIX: Wrapped connection management in a valid runtime block to trap unhandled execution errors
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Database unavailable. Ensure XAMPP is running.");
                return;
            }

            try {
                conn.setAutoCommit(false);

                String insertOrder = "INSERT INTO orders (total_amount, payment_method) VALUES (?, ?)";
                PreparedStatement pstOrder = conn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS);
                pstOrder.setDouble(1, currentOrder.getGrandTotal());
                pstOrder.setString(2, selectedPayment);
                pstOrder.executeUpdate();

                ResultSet rs = pstOrder.getGeneratedKeys();
                int orderId = rs.next() ? rs.getInt(1) : 0;

                String insertDetails = "INSERT INTO orderdetails (order_id, product_id, product_name, quantity, subtotal) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pstDetails = conn.prepareStatement(insertDetails);

                for (CartItem item : currentOrder.getCartItems()) {
                    pstDetails.setInt(1, orderId);
                    // FIX: Pass string value to match database table layout expectations
                    pstDetails.setString(2, String.valueOf(item.getProductId()));
                    pstDetails.setString(3, item.getProductName());
                    pstDetails.setInt(4, item.getQuantity());
                    pstDetails.setDouble(5, item.getSubtotal());
                    pstDetails.addBatch();
                }

                pstDetails.executeBatch();
                conn.commit();

                JOptionPane.showMessageDialog(this,
                        "Payment Successful!\nReceipt No: " + orderId +
                        "\nTotal: RM " + String.format("%.2f", currentOrder.getGrandTotal()));

                currentOrder = new Order();
                tableModel.setRowCount(0);
                lblTotal.setText("Total: RM 0.00");

            } catch (SQLException ex) {
                try { conn.rollback(); } catch (SQLException ignored) {}
                JOptionPane.showMessageDialog(this, "Database Transaction Error: " + ex.getMessage());
            } finally {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Connection Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new SalesPOS().setVisible(true));
    }
}