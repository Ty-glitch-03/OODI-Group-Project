
package com.mycompany.skincaremanagement;


public class StockAlert {

    // Alert severity levels (demonstrates use of constants / design)
    public static final String SEVERITY_CRITICAL = "CRITICAL"; // qty <= 1
    public static final String SEVERITY_LOW      = "LOW";      // qty <= 3
    public static final String SEVERITY_WARNING  = "WARNING";  // qty <= 5

    // Attributes
    private String productId;
    private String productName;
    private int currentQty;
    private int reorderLevel;
    private String severity;
    private String supplierName;

    // Constructor
    public StockAlert(String productId, String productName, int currentQty,
                      int reorderLevel, String supplierName) {
        this.productId    = productId;
        this.productName  = productName;
        this.currentQty   = currentQty;
        this.reorderLevel = reorderLevel;
        this.supplierName = supplierName;
        this.severity     = calculateSeverity(currentQty);
    }

    // Determines alert severity based on quantity
    private String calculateSeverity(int qty) {
        if (qty <= 1) return SEVERITY_CRITICAL;
        if (qty <= 3) return SEVERITY_LOW;
        return SEVERITY_WARNING;
    }

    // Getters
    public String getProductId()    { return productId; }
    public String getProductName()  { return productName; }
    public int getCurrentQty()      { return currentQty; }
    public int getReorderLevel()    { return reorderLevel; }
    public String getSeverity()     { return severity; }
    public String getSupplierName() { return supplierName; }

    /**
     * Returns a display string for showing in the JList.
     */
    public String getDisplayString() {
        return String.format("[%s] %s - %s (Qty: %d)",
            severity, productId, productName, currentQty);
    }

    @Override
    public String toString() {
        return getDisplayString();
    }
}
