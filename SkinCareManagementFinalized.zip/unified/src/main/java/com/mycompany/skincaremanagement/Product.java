/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;

/**
 *
 * @author ASUS
 */
public class Product {
    
    private String productId;
    private String productName;
    private String brand;
    private String category;
    private String skinType;
    private double price;
    private int stock;

    public Product(String productId,
                   String productName,
                   String brand,
                   String category,
                   String skinType,
                   double price,
                   int stock) {

        this.productId = productId;
        this.productName = productName;
        this.brand = brand;
        this.category = category;
        this.skinType = skinType;
        this.price = price;
        this.stock = stock;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getBrand() {
        return brand;
    }

    public String getCategory() {
        return category;
    }

    public String getSkinType() {
        return skinType;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setSkinType(String skinType) {
        this.skinType = skinType;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
