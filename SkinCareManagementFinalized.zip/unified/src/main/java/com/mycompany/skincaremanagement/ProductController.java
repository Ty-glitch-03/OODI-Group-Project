/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author ASUS
 */
public class ProductController {
    public boolean addProduct(Product product) {

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            String sql =
                    "INSERT INTO Product VALUES (?,?,?,?,?,?,?)";

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setString(1, product.getProductId());
            pst.setString(2, product.getProductName());
            pst.setString(3, product.getBrand());
            pst.setString(4, product.getCategory());
            pst.setString(5, product.getSkinType());
            pst.setDouble(6, product.getPrice());
            pst.setInt(7, product.getStock());

            pst.executeUpdate();

            return true;

        } catch(Exception e){

            return false;
        }
    }
}
