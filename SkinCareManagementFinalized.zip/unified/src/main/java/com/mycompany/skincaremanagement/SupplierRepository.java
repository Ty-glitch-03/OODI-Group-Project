/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;
import java.sql.Connection;
import java.sql.Statement;


/**
 *
 * @author ASUS
 */
public class SupplierRepository {
    public static void saveSupplier(String id, String name, String regNo, String email, String category) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement st = conn.createStatement();
            
            String query = "INSERT INTO tbl_supplier VALUES ('" + id + "', '" + name + "', '" + regNo + "', '" + email + "', '" + category + "', 'Active')";
            
            st.executeUpdate(query);
            st.close();
            conn.close();
            System.out.println(">>> SQL STATUS: Berjaya INSERT ID " + id);
            
        } catch (Exception e) {
            System.out.println(">>> SQL ERROR (INSERT): " + e.getMessage());
        }
    }

    public static void updateSupplier(String id, String name, String email, String status) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement st = conn.createStatement();
            
            String query = "UPDATE tbl_supplier SET name='" + name + "', email='" + email + "', status='" + status + "' WHERE id='" + id + "'";
            
            st.executeUpdate(query);
            st.close();
            conn.close();
            System.out.println(">>> SQL STATUS: Berjaya UPDATE ID " + id);
            
        } catch (Exception e) {
            System.out.println(">>> SQL ERROR (UPDATE): " + e.getMessage());
        }
    }

    public static void deleteSupplier(String id) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement st = conn.createStatement();
            
            String query = "DELETE FROM tbl_supplier WHERE id='" + id + "'";
            
            st.executeUpdate(query);
            st.close();
            conn.close();
            System.out.println(">>> SQL STATUS: Berjaya DELETE ID " + id);
            
        } catch (Exception e) {
            System.out.println(">>> SQL ERROR (DELETE): " + e.getMessage());
        }
    }
}

