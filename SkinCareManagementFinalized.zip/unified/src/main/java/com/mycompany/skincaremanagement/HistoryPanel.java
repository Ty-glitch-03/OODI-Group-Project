/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;
import javax.swing.*;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;


import javax.swing.table.TableRowSorter; 
import javax.swing.RowFilter;

/**
 *
 * @author Acer
 */
public class HistoryPanel extends javax.swing.JPanel {
    private DefaultTableModel historyTableModel;

    /**
     * Creates new form HistoryPanel
     */
    public HistoryPanel() {
        initComponents();
        initManualLayout();
        loadHistoryFromDatabase();
    }
    
    private void initManualLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Staff Enquiry Hub"));
        
        
        JTextField txtSearch = new JTextField(15);
        JButton btnSearch = new JButton("Search");
        JButton btnViewProfile = new JButton("View Full Profile");
        searchPanel.add(new JLabel("Keyword:")); searchPanel.add(txtSearch);
        searchPanel.add(btnSearch); searchPanel.add(btnViewProfile);

        String[] columns = {"Supplier ID", "Name", "Category", "Reg Num", "Current Status"};
        historyTableModel = new DefaultTableModel(columns, 0);

        JTable historyTable = new JTable(historyTableModel);
        
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(historyTableModel);
        historyTable.setRowSorter(sorter);
        add(searchPanel, BorderLayout.NORTH);
        add(new JScrollPane(historyTable), BorderLayout.CENTER);

        
        btnSearch.addActionListener(e -> {
           String text = txtSearch.getText().trim();
            
            if (text.isEmpty()) {
                sorter.setRowFilter(null);
            } else {
                try {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Filter Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnViewProfile.addActionListener(e -> {
            int row = historyTable.getSelectedRow();
            if(row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row in the table!", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String sId = historyTableModel.getValueAt(row, 0).toString();
            String sName = historyTableModel.getValueAt(row, 1).toString();
            String sAction = historyTableModel.getValueAt(row, 2).toString();
            String sDoc = historyTableModel.getValueAt(row, 3).toString();
            String sStatus = historyTableModel.getValueAt(row, 4).toString();

            String msg = "===SUPPLIER PROFILE (READ-ONLY) ===\n" +
                         "ID: " + sId + "\nName: " + sName + "\nStatus: " + sStatus + "\n\n" +
                         "===PURCHASE ORDER HISTORY ===\n" +
                         "Last Action: " + sAction + "\nDoc Ref: " + sDoc;
            JOptionPane.showMessageDialog(this, msg, "Staff View Portal", JOptionPane.INFORMATION_MESSAGE);
        });
    }
    
    public void loadHistoryFromDatabase() {
        
        historyTableModel.setRowCount(0);
        
        String query = "SELECT id, name, category, reg_no, status FROM tbl_supplier ORDER BY id ASC";

        try (Connection conn = DatabaseConnection.getConnection();
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                
                String id = rs.getString("id");
                String name = rs.getString("name");
                String category = rs.getString("category"); 
                String regNo = rs.getString("reg_no"); 
                String status = rs.getString("status");
                
                historyTableModel.addRow(new Object[]{id, name, category, regNo, status});
            }
            System.out.println(">>> LOG: Data dari phpMyAdmin berjaya di-load ke History Panel!");

        } catch (Exception e) {
            System.out.println(">>> ERROR: Gagal load data history dari DB! Sebab: " + e.getMessage());
            }
    }

public void addHistoryRecord(String id, String name, String category, String regNo, String status) {
    if (historyTableModel != null) {
        historyTableModel.addRow(new Object[]{id, name, category, regNo, status});
    }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The tent of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}

