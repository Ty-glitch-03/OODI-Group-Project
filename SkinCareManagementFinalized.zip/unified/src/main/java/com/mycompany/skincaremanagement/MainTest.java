package com.mycompany.skincaremanagement;

import java.time.LocalDate;
import java.sql.SQLException;

//This is a standalone test runner file. It allows us to test our database queries, 
//data mapping, and polymorphism without needing to open up the full visual UI screens.
public class MainTest {
    public static void main(String[] args) {
        System.out.println("====== STARTING REPORTING MODULE UNIT TESTS ======\n");

        //this is to test whether the java can interact with database
        System.out.println("Test: Verifying Relational Database Engine Connection...");
        
        try {
            if (DatabaseConnection.getConnection() != null) {
                System.out.println("SUCCESS: Database connection established successfully!\n");
            } else {
                // Throw warning msg if the user forgot to start their local database tools
                System.out.println("FAILURE: Database connection failed. Verify DatabaseConnection class parameters.\n");
                return;
            }
            //error msg if user forgot to start local fatabase tool
        } catch (SQLException e) {
            System.out.println("FAILURE: Database error occurred! Make sure XAMPP is running. Error: " + e.getMessage());
            return;
        }
        
        //this is to initialize controller core layer
        ReportController rc = new ReportController();
        
        //this is to test controller report
        System.out.println("Test: Testing SalesReport Data Mapping Pipeline...");
        LocalDate startDate = LocalDate.now().minusMonths(1);
        LocalDate endDate = LocalDate.now();
        
        Report report = rc.generateSalesReport(startDate, endDate);
        
        if (report != null) {
            System.out.println("SUCCESS: Analytical data models retrieved and instantiated correctly!");
            
            System.out.println("REPORT OUTPUT SUMMARY:");
            //Calls the summary block to print everything
            System.out.println(report.getReportSummary());
            System.out.println();
        } else {
            System.out.println("FAILURE: Report generation returned null. Ensure the 'sales' table contains data between " + startDate + " and " + endDate + ".\n");
        }

        //Test that the objects are being grouped polymorphically in collection list
        System.out.println("Test: Validating Dynamic Polymorphic Collection Tracking Engine...");
        rc.printProcessedReportsSummary();
        
        System.out.println("\n====== ALL MODULE UNIT TESTS EXECUTED COMPLETELY ======");
    }
}