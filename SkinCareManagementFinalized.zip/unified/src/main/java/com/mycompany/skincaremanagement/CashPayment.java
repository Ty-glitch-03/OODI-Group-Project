package com.mycompany.skincaremanagement;

public class CashPayment extends Payment {

    private double cashTendered;
    private double change;

    public CashPayment(double amountToPay, double cashTendered) {
        super(amountToPay);
        this.cashTendered = cashTendered;
    }

    public double getChange() {
        return change;
    }

    @Override
    public boolean processTransaction() {
        if (cashTendered >= amountToPay) {
            change = cashTendered - amountToPay;
            return true;
        }

        return false;
    }
}