/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;

/**
 *
 * @author ASUS
 */


public class ProductData {
public static Product[] products = new Product[100];
       // Number of products currently stored
    public static int count = 0;

    // Add product into array
    public static void addProduct(Product product) {

        if (count < products.length) {

            products[count] = product;
            count++;

        } else {

            System.out.println("Array is full!");
        }
    }

    // Get product by index
    public static Product getProduct(int index) {

        if (index >= 0 && index < count) {
            return products[index];
        }

        return null;
    }

    // Get all products
    public static Product[] getProducts() {

        return products;
    }

    // Get total products
    public static int getCount() {

        return count;
    }

    // Delete product by product ID
    public static boolean deleteProduct(String productId) {

        for (int i = 0; i < count; i++) {

            if (products[i].getProductId().equals(productId)) {

                for (int j = i; j < count - 1; j++) {

                    products[j] = products[j + 1];
                }

                products[count - 1] = null;
                count--;

                return true;
            }
        }

        return false;
    }

    // Search product by ID
    public static Product searchProduct(String productId) {

        for (int i = 0; i < count; i++) {

            if (products[i].getProductId().equals(productId)) {

                return products[i];
            }
        }

        return null;
    }
}