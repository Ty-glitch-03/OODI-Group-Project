package com.mycompany.skincaremanagement;

public abstract class Payment {

    protected double amountToPay;

    public Payment(double amountToPay) {
        this.amountToPay = amountToPay;
    }

    public double getAmountToPay() {
        return amountToPay;
    }

    public abstract boolean processTransaction();
}