package com.mycompany.skincaremanagement;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

//This class serves as our controller. It cleanly separates backend database functions 
 //away from our visual User Interface screens.

public class ReportController {

    private static final Logger logger = Logger.getLogger(ReportController.class.getName());
    
    //Polymorphism
    // create a list using the abstract parent type 'Report'. 
    // This allows the list to store SalesReports, or any future report type.
    private final List<Report> processedReportsHistory;

    public ReportController() {
        this.processedReportsHistory = new ArrayList<>(); //Here I use arrayList
    }

    //Data Sharing Between Teammates (Cross integration)
    //This method reads data from the 'orders' table and wrap into factory
    public Report generateSalesReport(LocalDate startDate, LocalDate endDate) {
        String sql = "SELECT COUNT(*) AS total_transactions, " +
                     "SUM(total_amount) AS total_sales, " +
                     "SUM(total_amount * 0.30) AS total_profit " + 
                     "FROM orders " +
                     "WHERE DATE(order_date) BETWEEN ? AND ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                logger.severe("Cannot generate report: database not connected.");
                return null;
            }

            //Uses safe PreparedStatement placeholders (?, ?) to filter start and end dates securely
            //without risk of SQL Injection crashes
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDate(1, Date.valueOf(startDate));
                stmt.setDate(2, Date.valueOf(endDate));

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        // Extract raw metrics out of the database row
                        int totalTransactions = rs.getInt("total_transactions");
                        double totalSales     = rs.getDouble("total_sales");
                        double totalProfit    = rs.getDouble("total_profit");

                        // Create a unique system tracking code using milliseconds
                        String reportId = "RPT-" + System.currentTimeMillis();
                        
                        // Instead of hardcoding 'new SalesReport()', the database values pass 
                        // into Factory class. The factory manufactures and returns the object polymorphically.
                        Report report = ReportFactory.createReport("SALES", reportId, startDate, endDate,
                                                                   totalSales, totalTransactions, totalProfit);
                        
                        // Save the newly manufactured object straight into our generic history list
                        if (report != null) {
                            processedReportsHistory.add(report);
                        }
                        return report;
                    }
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to generate sales report: " + e.getMessage(), e);
        }
        return null;
    }

     //System Integration
     //This method reads records directly from the 'products' table managed by Module 1.
     //It scans the store stock levels to find items dropping below safe minimum limits.
    public List<StockAlert> getLowStockAlerts() {
        List<StockAlert> alerts = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE quantity <= alert_threshold";

        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                logger.severe("Cannot fetch alerts: database not connected.");
                return alerts;
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                // // Loop through the low stock rows and package them into objects
                while (rs.next()) {
                    String id = rs.getString("product_id");
                    String name = rs.getString("product_name");
                    int qty = rs.getInt("quantity");
                    int threshold = rs.getInt("alert_threshold");
                    String supplier = rs.getString("supplier_name");

                    StockAlert alert = new StockAlert(id, name, qty, threshold, supplier);
                    alerts.add(alert);
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to fetch low stock alerts: " + e.getMessage(), e);
        }
        return alerts;
    }

    //Tells MySQL to calculate category revenues directly inside the database engine
    public String getProfitAnalysis(LocalDate startDate, LocalDate endDate) {
        String sql = "SELECT 'General Store Sales' AS category, " +
                     "SUM(total_amount) AS revenue, " +
                     "SUM(total_amount * 0.30) AS profit " + 
                     "FROM orders " +
                     "WHERE DATE(order_date) BETWEEN ? AND ?";

        StringBuilder sb = new StringBuilder();
        sb.append("=== Profit Analysis ===\n");
        sb.append(String.format("Period: %s to %s\n\n", startDate, endDate));
        sb.append(String.format("%-20s %-15s %-15s\n", "Category", "Revenue (RM)", "Profit (RM)"));
        sb.append("-".repeat(52)).append("\n");

        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) return "Error: Database not connected.";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDate(1, Date.valueOf(startDate));
                stmt.setDate(2, Date.valueOf(endDate));

                try (ResultSet rs = stmt.executeQuery()) {
                    boolean hasData = false;
                    while (rs.next()) {
                        //Logical validation where only print rows 
                        //if there are actual sales recorded
                        if (rs.getDouble("revenue") > 0) {
                            hasData = true;
                            sb.append(String.format("%-20s %-15.2f %-15.2f\n",
                                rs.getString("category"),
                                rs.getDouble("revenue"),
                                rs.getDouble("profit")));
                        }
                    }
                    if (!hasData) sb.append("No sales data found for this period.\n");
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Profit analysis query failed: " + e.getMessage(), e);
            return "Error retrieving profit data.";
        }
        return sb.toString();
    }

    //CRUD Persistent Storage (Create,Read,Update,Delete)
    //Executes an INSERT statement to save file tracking links inside the database.
    //This guarantees the history is safely remembered even if the computer restarts
    public boolean saveToArchive(String reportId, String filePath) {
        String sql = "INSERT INTO archived_reports (report_id, file_path, export_date) VALUES (?, ?, ?)";
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                logger.warning("Database not connected during archival execution operation.");
                return false;
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, reportId);
                stmt.setString(2, filePath); 
                stmt.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
                
                stmt.executeUpdate(); // Execute the SQL insert query
                logger.info("Report " + reportId + " successfully registered into system archives.");
                return true;
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database Insert Error encountered inside saveToArchive: " + e.getMessage(), e);
            return false;
        }
    }

    //Dynamic Polymorphism (Overriding)
     //Loops through generic history list. At runtime, Java automatically looks at 
     //each object and executes its specific child version of '.getReportSummary()'.
    public void printProcessedReportsSummary() {
        System.out.println("--- Polymorphic Execution Logging Queue ---");
        for (Report r : processedReportsHistory) {
            // Runtime Binding Call: The compiler sees a generic parent 'Report', but 
            // Java triggers the correct child output details automatically while running
            System.out.println(r.getReportSummary());
        }
    }
}