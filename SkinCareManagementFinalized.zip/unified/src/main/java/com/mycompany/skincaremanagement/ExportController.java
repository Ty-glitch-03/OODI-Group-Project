package com.mycompany.skincaremanagement;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class is actually handles the writing and exporting files to the disk. It separates core physical 
 * file operations completely away from our UI buttons and layouts.
 */
public class ExportController {

    private static final Logger logger = Logger.getLogger(ExportController.class.getName());
    
    // Relative path folder name where our reports will be saved on the computer
    private static final String EXPORT_DIR = "Archived_Reports/";

    /**
     * Main export runner method.
     * Dynamic Polymorphism
     * In the report class, we had put the getSummaryReport in abstract class
     * which means we don't have a specific form of summary
     * So now we give one specific form for report method: report method
    */
    
    public String exportReport(Report report, String format) {
        if (report == null) {
            logger.severe("Export aborted: Provided report object structure reference is null.");
            return null;
        }

        //Create the destination folder if it doesn't exist yet
        File dir = new File(EXPORT_DIR); //dir stands for directory
        if (!dir.exists()) { //if dir not exist
            dir.mkdirs(); //make new dir
        }
        
        System.out.println("DEBUG: Folder storage location confirmed at: " + dir.getAbsolutePath());

        //Generate a clean unique file name using the current date and time
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String fileName  = report.getClass().getSimpleName() + "_" + timestamp;

        //choose the file type either in CSV or TXT
        switch (format.toUpperCase()) {
            case "CSV":
                // Downcasting (converting a generic parent reference back into its specific child subclass)
                // We use 'instanceof' to safely verify if this generic report is actually a SalesReport,
                // Let me open it up so I can pull out the exact sales numbers for the spreadsheet columns
                if (report instanceof SalesReport) {
                    return exportAsCSV((SalesReport) report, EXPORT_DIR + fileName + ".csv");
                } else {
                    logger.warning("CSV export format is not configured for generic report classifications.");
                    return null;
                }
            case "TXT":
                
                // Dynamic Polymorphism
                // Text files can be written using generic parent methods without needing explicit downcasting.
                return exportAsTXT(report, EXPORT_DIR + fileName + ".txt");
            default:
                logger.warning("System configuration does not support format: " + format);
                return null;
        }
    }

    /**
     * Polymorphic Operations
     * Another form of getSummaryReport
     */
    private String exportAsTXT(Report report, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("===== SYSTEM REPORT EXPORT =====\n");
            
            //Runtime Binding Call( getReportSummary here is like let the java know the TXT report is actually
            //from the abstract class of getReportSummary
            writer.write(report.getReportSummary());
            writer.newLine();
            
            File savedFile = new File(filePath);
            System.out.println("SUCCESS: Document physically committed to disk at: " + savedFile.getAbsolutePath());
            return filePath;
            
        } catch (IOException e) {
            logger.log(Level.SEVERE, "IO Exception encountered during plain text file creation: " + e.getMessage(), e);
            return null;
        }
    }

    //Logical Problem Solving
   //Formats specific child report properties into a CSV layout
    
    private String exportAsCSV(SalesReport report, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write standard spreadsheet columns headers
            writer.write("Report ID,Start Date,End Date,Total Sales (RM),Transactions,Total Profit (RM),Status");
            writer.newLine();
            
            // Extract the private object metrics safely via the encapsulation accessor getters
            writer.write(String.format("%s,%s,%s,%.2f,%d,%.2f,%s",
                report.getReportId(),
                report.getStartDate(),
                report.getEndDate(),
                report.getTotalSales(),
                report.getTotalTransactions(),
                report.getTotalProfit(),
                "FINALIZED")); 
            writer.newLine();
            
            File savedFile = new File(filePath);
            System.out.println("✅ SUCCESS: CSV dataset physically committed to disk at: " + savedFile.getAbsolutePath());
            return filePath;
            
        } catch (IOException e) {
            logger.log(Level.SEVERE, "IO Exception encountered during CSV dataset creation: " + e.getMessage(), e);
            return null;
        }
    }
}