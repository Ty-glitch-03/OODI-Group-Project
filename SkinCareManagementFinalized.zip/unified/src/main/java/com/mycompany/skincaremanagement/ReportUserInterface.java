package com.mycompany.skincaremanagement;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class ReportUserInterface extends JFrame {

    // Connects to your backend logic
    private ReportController rc;
    
    // Global UI Colors
    private static final Color BG_DARK      = new Color(24, 24, 36);
    private static final Color BG_CARD      = new Color(36, 36, 54);
    private static final Color ACCENT_BLUE  = new Color(80, 160, 230);
    private static final Color TEXT_WHITE   = new Color(240, 240, 250);

    public ReportUserInterface() {
        rc = new ReportController(); // Initialize the controller

        // Window Setup
        setTitle("Skin Care Inventory & Sales Management (Reporting & Analytics)");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        //Header Panel (Dark background) ───
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BG_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lblTitle = new JLabel("REPORTING & ANALYTICS DASHBOARD");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(TEXT_WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);

        JButton btnBack = new JButton("← Back to Dashboard");
        btnBack.setBackground(ACCENT_BLUE); 
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        //Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabbedPane.setBackground(BG_DARK);
        tabbedPane.setForeground(TEXT_WHITE);

        //4 main functions as tabs
        tabbedPane.addTab("Generate Sales Report", createSalesReportPanel());
        tabbedPane.addTab("Export Report", createExportPanel());
        tabbedPane.addTab("View Stock Alerts", createStockAlertsPanel());
        tabbedPane.addTab("Profit Analysis", createProfitAnalysisPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    //Generate Sales Report (Design)
    private JPanel createSalesReportPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG_DARK);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(BG_DARK);
        
        JLabel lblTitle = new JLabel("Generate 30-Day Sales Report:");
        lblTitle.setForeground(TEXT_WHITE);
        
        JButton btnGenerate = new JButton("Generate Report");
        btnGenerate.setBackground(ACCENT_BLUE);
        btnGenerate.setForeground(Color.WHITE);
        
        topPanel.add(lblTitle);
        topPanel.add(btnGenerate);
        panel.add(topPanel, BorderLayout.NORTH);
        
        JTextArea txtDisplay = new JTextArea("Click 'Generate Report' to view recent sales data...");
        styleTextArea(txtDisplay);
        panel.add(new JScrollPane(txtDisplay), BorderLayout.CENTER);
        
        // ACTION LOGIC:
        btnGenerate.addActionListener(e -> {
            LocalDate endDate = LocalDate.now();
            LocalDate startDate = endDate.minusMonths(1); // Last 30 days
            
            
          // instead of using (SalesReport report = new SalesReport(reportId, startDate, endDate,
          //totalSales, totalTransactions, totalProfit);)
            Report report = rc.generateSalesReport(startDate, endDate); //rc: ReportController
            if (report != null) {
                txtDisplay.setText(report.getReportSummary());
            } else {
                txtDisplay.setText("No sales data found for the last 30 days or database connection failed.");
            }
        });
        
        return panel;
    }

    //Export Report (Design)
    private JPanel createExportPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG_DARK);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(BG_DARK);
        
        JLabel lblTitle = new JLabel("Archive Current System Data:");
        lblTitle.setForeground(TEXT_WHITE);
        
        JButton btnExport = new JButton("Archive to Database");
        btnExport.setBackground(ACCENT_BLUE);
        btnExport.setForeground(Color.WHITE);
        
        topPanel.add(lblTitle);
        topPanel.add(btnExport);
        panel.add(topPanel, BorderLayout.NORTH);
        
        JTextArea txtDisplay = new JTextArea("Ready to archive report references into the database...");
        styleTextArea(txtDisplay);
        panel.add(new JScrollPane(txtDisplay), BorderLayout.CENTER);

        // ACTION LOGIC:
        btnExport.addActionListener(e -> {
            String reportId = "ARCHIVE-" + System.currentTimeMillis();
            boolean success = rc.saveToArchive(reportId, "/reports/auto_archive.csv");
            if(success) {
                txtDisplay.setText("SUCCESS: Report " + reportId + " successfully registered into system archives.");
            } else {
                txtDisplay.setText("FAILED: Could not save archive to database.");
            }
        });

        return panel;
    }

    //View Stock Alerts (Design)
    private JPanel createStockAlertsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG_DARK);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(BG_DARK);
        
        JLabel lblTitle = new JLabel("Check Inventory for Low Stock:");
        lblTitle.setForeground(TEXT_WHITE);
        
        JButton btnAlerts = new JButton("Check Stock");
        btnAlerts.setBackground(ACCENT_BLUE);
        btnAlerts.setForeground(Color.WHITE);
        
        topPanel.add(lblTitle);
        topPanel.add(btnAlerts);
        panel.add(topPanel, BorderLayout.NORTH);
        
        JTextArea txtDisplay = new JTextArea("Click 'Check Stock' to scan for inventory warnings...");
        styleTextArea(txtDisplay);
        panel.add(new JScrollPane(txtDisplay), BorderLayout.CENTER);

        // ACTION LOGIC:
        btnAlerts.addActionListener(e -> {
            List<StockAlert> alerts = rc.getLowStockAlerts();
            if (alerts.isEmpty()) {
                txtDisplay.setText("Inventory looks good! No items are currently below the threshold.");
            } else {
                StringBuilder sb = new StringBuilder("=== LOW STOCK INVENTORY ALERTS ===\n\n");
               for (StockAlert a : alerts) {
                    sb.append("Product ID: ").append(a.getProductId()).append("\n");
                    sb.append("Name: ").append(a.getProductName()).append("\n");
                    sb.append("Current Stock: ").append(a.getCurrentQty()).append(" (Threshold: ").append(a.getReorderLevel()).append(")\n");
                    sb.append("---------------------------------------\n");
                }
                txtDisplay.setText(sb.toString());
            }
        });

        return panel;
    }

    //Profit Analysis (Design)
    private JPanel createProfitAnalysisPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG_DARK);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(BG_DARK);
        
        JLabel lblTitle = new JLabel("Analyze 30-Day Profit by Category:");
        lblTitle.setForeground(TEXT_WHITE);
        
        JButton btnAnalyze = new JButton("Run Analysis");
        btnAnalyze.setBackground(ACCENT_BLUE);
        btnAnalyze.setForeground(Color.WHITE);
        
        topPanel.add(lblTitle);
        topPanel.add(btnAnalyze);
        panel.add(topPanel, BorderLayout.NORTH);
        
        JTextArea txtDisplay = new JTextArea("Click 'Run Analysis' to fetch category profit breakdowns...");
        styleTextArea(txtDisplay);
        panel.add(new JScrollPane(txtDisplay), BorderLayout.CENTER);

        // ACTION LOGIC:
        btnAnalyze.addActionListener(e -> {
            LocalDate endDate = LocalDate.now();
            LocalDate startDate = endDate.minusMonths(1);
            String analysisData = rc.getProfitAnalysis(startDate, endDate);
            txtDisplay.setText(analysisData);
        });

        return panel;
    }

    
// Below line is to make the interface look attractive
    private void styleTextArea(JTextArea area) {
        area.setEditable(false);
        area.setBackground(BG_CARD);
        area.setForeground(TEXT_WHITE);
        area.setFont(new Font("Monospaced", Font.PLAIN, 13));
        area.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    //Main function (we use try...catch method)
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } 
        catch (Exception ignored) {}
        
        //setVisible to ensure the interface is visible & can be shown
        SwingUtilities.invokeLater(() -> new ReportUserInterface().setVisible(true));
    }
}