package com.mycompany.skincaremanagement;

import java.time.LocalDate;

// This model class is actually represents a specific type of report. 
 
 //Inheritance
 //We use the 'extends' keyword so that 'SalesReport' inherits general features 
 //(like reportId and generatedDate) from the abstract parent class 'Report')(line 13&14)
public class SalesReport extends Report {
    
    // Encapsulation: Hiding the data (Data Hiding)
    // All variables are uses the modifier: 'private' ,to protect them from direct unauthorized modification.
    private LocalDate startDate;
    private LocalDate endDate;
    private double totalSales;
    private int totalTransactions;
    private double totalProfit;

   
     //Constructor Method
     //Parent Constructor Invocation
     //Here the data will be requested from the factory
    public SalesReport(String reportId, LocalDate startDate, LocalDate endDate, 
                       double totalSales, int totalTransactions, double totalProfit) {
        
     //'super(reportId)' used to send the identification string up to the parent 'Report' 
       // class so it can initialize the shared background properties automatically.
     
       //variable calling in factory class
        super(reportId); 
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalSales = totalSales;
        this.totalTransactions = totalTransactions;
        this.totalProfit = totalProfit;
    }

    // Encapsulation (getter)
    // Because variables are private, so read-only public getter methods is used 
    // so other classes can read these values safely.
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public double getTotalSales() { return totalSales; }
    public int getTotalTransactions() { return totalTransactions; }
    public double getTotalProfit() { return totalProfit; }

    
     //Polymorphism (Method Overriding)
     //I use the '@Override' keyword to change the behavior of the parent's abstract method.
     //so the java know now I am customizing the report, and also let java know 
     //this is the report format that I want
    @Override
    public String getReportSummary() {
        StringBuilder sb = new StringBuilder(); //sb: StringBuilder
        sb.append("==================================================\n");
        sb.append("          STORE PERFORMANCE SALES REPORT          \n");
        sb.append("==================================================\n");
        // 'getReportId()' is inherited seamlessly from the parent 'Report' class
        sb.append(String.format("Report ID      : %s\n", getReportId()));
        sb.append(String.format("Period         : %s  to  %s\n", startDate, endDate));
        sb.append("--------------------------------------------------\n");
        sb.append("METRIC SUMMARY:\n");
        sb.append(String.format("Total Transactions : %d\n", totalTransactions));
        sb.append(String.format("Gross Revenue      : RM %.2f\n", totalSales));
        sb.append(String.format("Net Margin Profit  : RM %.2f\n", totalProfit));
        sb.append("--------------------------------------------------\n");
        sb.append("Operational Status: FINALIZED & RECORDED\n");
        sb.append("==================================================\n");
        return sb.toString();
    }
}