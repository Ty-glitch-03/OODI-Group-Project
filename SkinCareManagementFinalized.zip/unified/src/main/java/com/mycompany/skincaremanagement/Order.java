package com.mycompany.skincaremanagement;

public class Order {

    private CartItem[] cartItems;
    private int itemCount;
    private final int MAX_ITEMS = 100;
    private double grandTotal;

    public Order() {
        cartItems = new CartItem[MAX_ITEMS];
        itemCount = 0;
        grandTotal = 0.0;
    }

    public void addItem(CartItem item) {
        if (itemCount < MAX_ITEMS) {
            cartItems[itemCount] = item;
            itemCount++;
            calculateTotal();
        }
    }

    private void calculateTotal() {
        grandTotal = 0;

        for (int i = 0; i < itemCount; i++) {
            grandTotal += cartItems[i].getSubtotal();
        }
    }

    public double getGrandTotal() {
        return grandTotal;
    }

    public int getItemCount() {
        return itemCount;
    }

    public CartItem[] getCartItems() {
        CartItem[] items = new CartItem[itemCount];

        for (int i = 0; i < itemCount; i++) {
            items[i] = cartItems[i];
        }

        return items;
    }

    public boolean checkout(Payment payment) {
        if (itemCount == 0) {
            return false;
        }

        return payment.processTransaction();
    }
}