package com.mycompany.skincaremanagement;

import java.time.LocalDate;

 //Abstraction
 //This abstract class serves as the unified base architectural layer for system reports.
 //Enforces a strict common design pattern across different reporting structures.
 
public abstract class Report {
    
    //Encapsulation (The variable is wrap in private modifier)
    private String reportId;
    private LocalDate generatedDate;


     //constructor for all generalized reports.
    
    public Report(String reportId) {
        this.reportId = reportId;
        this.generatedDate = LocalDate.now(); // the date can be automatically catched based on real life
    }

    // Encapsulation accessors (Getters & Setters)
    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public LocalDate getGeneratedDate() {
        return generatedDate;
    }

    public void setGeneratedDate(LocalDate generatedDate) {
        this.generatedDate = generatedDate;
    }

     //Polymorphism
     //Abstract signature forcing subclasses to supply customized summary
    public abstract String getReportSummary();
}