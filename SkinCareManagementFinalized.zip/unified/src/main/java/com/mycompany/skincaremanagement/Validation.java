/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;

/**
 *
 * @author ASUS
 */
public class Validation {
    public static boolean validateData(String id, String name, String regNo, String email) {
        if(id.isEmpty() || name.isEmpty() || regNo.isEmpty() || email.isEmpty()) {
            return false;
        }
        
        return email.contains("@") && email.contains(".");
    }

}
