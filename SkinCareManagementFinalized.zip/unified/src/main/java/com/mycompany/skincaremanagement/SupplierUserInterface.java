
package com.mycompany.skincaremanagement;

import javax.swing.*;
import java.util.logging.Logger;

import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class SupplierUserInterface extends javax.swing.JFrame {

    private static final Logger logger = Logger.getLogger(SupplierUserInterface.class.getName());

    private final String productId;
    private final String productName;
    private final String supplierName;

    public SupplierUserInterface(String productId, String productName, String supplierName) {
        this.productId    = productId;
        this.productName  = productName;
        this.supplierName = supplierName;
        initComponents();
        populateDetails();
    }

    private void populateDetails() {
        lblProductId.setText("Product ID   : " + productId);
        lblProductName.setText("Product Name : " + productName);
        lblSupplier.setText("Supplier     : " + supplierName);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        lblTitle       = new javax.swing.JLabel();
        lblProductId   = new javax.swing.JLabel();
        lblProductName = new javax.swing.JLabel();
        lblSupplier    = new javax.swing.JLabel();
        btnOrder       = new javax.swing.JButton();
        btnClose       = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Supplier Details");

        lblTitle.setText("Supplier Information");
        lblTitle.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));

        btnOrder.setText("Place Restock Order");
        btnOrder.addActionListener(this::btnOrderActionPerformed);

        btnClose.setText("Close");
        btnClose.addActionListener(e -> dispose());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle)
                    .addComponent(lblProductId)
                    .addComponent(lblProductName)
                    .addComponent(lblSupplier)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnOrder)
                        .addGap(15)
                        .addComponent(btnClose)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20)
                .addComponent(lblTitle)
                .addGap(15)
                .addComponent(lblProductId)
                .addGap(8)
                .addComponent(lblProductName)
                .addGap(8)
                .addComponent(lblSupplier)
                .addGap(25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnOrder)
                    .addComponent(btnClose))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        pack();
    }

    private void btnOrderActionPerformed(java.awt.event.ActionEvent evt) {
        // In a real system, this would insert a purchase order into the DB
        int confirm = JOptionPane.showConfirmDialog(this,
                "Place restock order for:\n" + productName + "\nFrom supplier: " + supplierName + "?",
                "Confirm Order", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this,
                    "Order placed successfully for " + productName + "!",
                    "Order Confirmed", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        }
    }

    // Variables declaration
    private javax.swing.JLabel  lblTitle;
    private javax.swing.JLabel  lblProductId;
    private javax.swing.JLabel  lblProductName;
    private javax.swing.JLabel  lblSupplier;
    private javax.swing.JButton btnOrder;
    private javax.swing.JButton btnClose;
}

