/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skincaremanagement;

/**
 *
 * @author ASUS
 */
public class SupplierController {
     public static void submitRegistration(String id, String name, String regNo, String email, String category) {
        SupplierRepository.saveSupplier(id, name, regNo, email, category);
    }
    
    public static void submitUpdate(String id, String newName, String newEmail, String newStatus) {
        SupplierRepository.updateSupplier(id, newName, newEmail, newStatus);
    }
    
    public static void requestDelete(String id) {
        SupplierRepository.deleteSupplier(id);
    }

}
