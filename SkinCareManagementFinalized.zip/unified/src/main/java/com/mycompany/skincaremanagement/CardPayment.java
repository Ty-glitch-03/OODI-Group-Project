package com.mycompany.skincaremanagement;

public class CardPayment extends Payment {

    private String cardNumber;

    public CardPayment(double amountToPay, String cardNumber) {
        super(amountToPay);
        this.cardNumber = cardNumber;
    }

    @Override
    public boolean processTransaction() {
        return cardNumber != null && cardNumber.length() == 16;
    }
}