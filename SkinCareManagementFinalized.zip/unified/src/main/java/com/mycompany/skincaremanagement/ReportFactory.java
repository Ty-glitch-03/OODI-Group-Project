package com.mycompany.skincaremanagement;


import java.time.LocalDate;

 //Factory Pattern
 //This class centralizes object creation. Instead of using the 'new' keyword 
 //inside the controller, the system asks this Factory to build the object.
 
public class ReportFactory {

    
     //Factory method to generate different types of reports.
     //If we expand our skin care system in future to include Inventory Reports or Supplier Reports, 
     //we can easily add them to the factory without changing any database logic or user interface screens.
     //In class ReportUI, line 94 will explain about this
    //SalesReport report = new SalesReport(reportId, startDate, endDate, totalSales, totalTransactions, totalProfit);
    public static Report createReport(String type, String reportId, LocalDate startDate, LocalDate endDate, 
                                      double totalSales, int totalTransactions, double totalProfit) {
        
        if (type == null) {
            return null;
        }
        
        // If the requested type is "SALES", it returns a SalesReport object polymorphically
        if (type.equalsIgnoreCase("SALES")) {
            return new SalesReport(reportId, startDate, endDate, totalSales, totalTransactions, totalProfit);
        }
        
        // We can just simply add it in this class without breaking the rest of the application
        // The format is like this: 
        //if (type.equalsIgnoreCase("XXXX")) {
        //     return new InventoryReport(reportId, ...);
        // }

        return null;
    }
}