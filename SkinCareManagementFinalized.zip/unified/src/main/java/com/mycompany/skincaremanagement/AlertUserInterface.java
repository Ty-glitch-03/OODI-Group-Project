
package com.mycompany.skincaremanagement;

import java.util.List;
import java.util.logging.Logger;
import javax.swing.*;

import java.util.List;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


 //This UI is actually as the pop-out window when low stock

public class AlertUserInterface extends javax.swing.JFrame {

    private static final Logger logger = Logger.getLogger(AlertUserInterface.class.getName());
    
//the connection to call our backend data functions
    private final ReportController reportController = new ReportController();

    
    //Array List is used
    //This list holds the full stock alert records 
    //fetched from database tables
    private List<StockAlert> alertList_data;

    public AlertUserInterface() {
        initComponents();
        loadAlerts();
    }

    
    // Grabs the low-stock warning records from the database and displays them.
    private void loadAlerts() {
        alertList_data = reportController.getLowStockAlerts();
        
//If the database is empty or down, show a friendly pop-up message box
        if (alertList_data == null || alertList_data.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No low stock alerts found, or database is unavailable.",
                "Alert Info", JOptionPane.INFORMATION_MESSAGE);
            alertList.setListData(new String[]{"No alerts at this time."});
            
        } else {
            
            //Transform the raw data objects into simple text lines in list
            String[] displayItems = alertList_data.stream()
                    .map(StockAlert::getDisplayString)
                    .toArray(String[]::new);
            alertList.setListData(displayItems);
        }
    }
    
//The button design
    @SuppressWarnings("unchecked")
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        alertList    = new javax.swing.JList<>();
        lblTitle     = new javax.swing.JLabel();
        lblHint      = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Stock Alerts - Low Inventory");

        lblTitle.setText("Low Stock Alerts");
        lblTitle.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));

        lblHint.setText("Double-click an item to view supplier details and reorder.");
        lblHint.setFont(new java.awt.Font("Segoe UI", 0, 11));

        alertList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                alertListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(alertList);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle)
                    .addComponent(lblHint)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15)
                .addComponent(lblTitle)
                .addGap(5)
                .addComponent(lblHint)
                .addGap(10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }

    //Triggered automatically whenever a user interacts with the UI list box view
   
    private void alertListMouseClicked(java.awt.event.MouseEvent evt) {
        //Check if the user double-clicked an item on the screen
        if (evt.getClickCount() == 2) {
            int index = alertList.getSelectedIndex();
            
            //if clicked on a valid row item inside the data bounds
            if (index >= 0 && alertList_data != null && index < alertList_data.size()) {
                StockAlert selected = alertList_data.get(index);
                
                //This allow the user seamlessly launch the supplier window so that the admin
                //can do reordering after that
                new SupplierUserInterface(selected.getProductId(), selected.getProductName(),
                        selected.getSupplierName()).setVisible(true);
            }
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new AlertUserInterface().setVisible(true));
    }

    // Variables declaration
    private javax.swing.JList<String>  alertList;
    private javax.swing.JScrollPane    jScrollPane1;
    private javax.swing.JLabel         lblTitle;
    private javax.swing.JLabel         lblHint;
}
