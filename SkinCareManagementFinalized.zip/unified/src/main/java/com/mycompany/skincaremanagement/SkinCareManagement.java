package com.mycompany.skincaremanagement;

/**
 * Application entry point.
 * Launches the MainDashboard which connects all 4 modules.
 */
public class SkinCareManagement {
    public static void main(String[] args) {
        MainDashboard.main(args);
    }
}
