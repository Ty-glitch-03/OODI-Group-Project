package com.mycompany.skincaremanagement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.SQLException;


 //Connects all 4 modules
 //All modules share ONE package and ONE DatabaseConnection (db_skincare).
 
public class MainDashboard extends JFrame {

    //To make the database look attractive, the colours & fonts are set
    private static final Color BG_DARK      = new Color(24, 24, 36);
    private static final Color BG_CARD      = new Color(36, 36, 54);
    private static final Color ACCENT_PINK  = new Color(230, 100, 140);
    private static final Color ACCENT_PURPLE= new Color(140, 100, 220);
    private static final Color ACCENT_GREEN = new Color(80, 200, 140);
    private static final Color ACCENT_BLUE  = new Color(80, 160, 230);
    private static final Color TEXT_WHITE   = new Color(240, 240, 250);
    private static final Color TEXT_GREY    = new Color(160, 160, 180);

    private static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_CARD_TITLE = new Font("Segoe UI", Font.BOLD, 15);
    private static final Font FONT_CARD_DESC  = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FONT_BTN      = new Font("Segoe UI", Font.BOLD, 13);

    // this is to show the status of database
    private JLabel lblDbStatus;

    public MainDashboard() {
        setTitle("Skin Care Inventory & Sales System — Main Dashboard");
        setSize(860, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout(0, 0));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildModulePanel(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        checkDatabaseConnection();
    }

    //Header
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(28, 40, 10, 40));

        //Title
        JPanel titleBlock = new JPanel();
        titleBlock.setBackground(BG_DARK);
        titleBlock.setLayout(new BoxLayout(titleBlock, BoxLayout.Y_AXIS));

        JLabel lblTitle = new JLabel("Skin Care Management System");
        lblTitle.setFont(FONT_TITLE);
        lblTitle.setForeground(TEXT_WHITE);

        JLabel lblSub = new JLabel("Integrated dashboard — select a module to begin");
        lblSub.setFont(FONT_SUBTITLE);
        lblSub.setForeground(TEXT_GREY);

        titleBlock.add(lblTitle);
        titleBlock.add(Box.createVerticalStrut(4));
        titleBlock.add(lblSub);

        //DB status (line 212)
        lblDbStatus = new JLabel("Checking DB...");
        lblDbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDbStatus.setForeground(TEXT_GREY);

        header.add(titleBlock, BorderLayout.WEST);
        header.add(lblDbStatus, BorderLayout.EAST);
        return header;
    }

    //Here the module card is created to display all four module, 
    //so the user can simply press which one they prefer
    
    private JPanel buildModulePanel() {
        JPanel grid = new JPanel(new GridLayout(2, 2, 20, 20));
        grid.setBackground(BG_DARK);
        grid.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));

        // Module 1
        grid.add(buildCard(
            "",
            "Product Management",
            "Add, update, delete products.\nSearch by name, brand, category.\nTrack stock levels & alerts.",
            ACCENT_PINK,
            e -> openModule1()
        ));

        // Module 2
        grid.add(buildCard(
            "",
            "Supplier Management",
            "Register & manage suppliers.\nHandle purchase orders.\nView supplier history.",
            ACCENT_PURPLE,
            e -> openModule2()
        ));

        // Module 3
        grid.add(buildCard(
            "",
            "Sales & Point of Sale",
            "Create customer orders.\nCart & checkout system.\nCash or card payment + invoice.",
            ACCENT_GREEN,
            e -> openModule3()
        ));

        // Module 4
        grid.add(buildCard(
            "",
            "Reporting & Analytics",
            "Generate sales reports.\nProfit analysis by category.\nLow stock alerts & CSV export.",
            ACCENT_BLUE,
            e -> openModule4()
        ));

        return grid;
    }

    //Attractive card panel are created for one module.
   
    private JPanel buildCard(String tag, String title, String description,
                              Color accentColour, ActionListener onOpen) {
        JPanel card = new JPanel();
        card.setBackground(BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(accentColour.darker(), 1),
            BorderFactory.createEmptyBorder(20, 22, 16, 22)
        ));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        //Here will show the module label
        JLabel lblTag = new JLabel(tag);
        lblTag.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTag.setForeground(accentColour);
        lblTag.setAlignmentX(LEFT_ALIGNMENT);

        // module title
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(FONT_CARD_TITLE);
        lblTitle.setForeground(TEXT_WHITE);
        lblTitle.setAlignmentX(LEFT_ALIGNMENT);

        //the module divider
        JSeparator sep = new JSeparator();
        sep.setForeground(accentColour.darker());
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setAlignmentX(LEFT_ALIGNMENT);

        //Description by HTML
        String htmlDesc = "<html>" + description.replace("\n", "<br>") + "</html>";
        JLabel lblDesc = new JLabel(htmlDesc);
        lblDesc.setFont(FONT_CARD_DESC);
        lblDesc.setForeground(TEXT_GREY);
        lblDesc.setAlignmentX(LEFT_ALIGNMENT);

        //Open button
        JButton btnOpen = new JButton("Open");
        btnOpen.setFont(FONT_BTN);
        btnOpen.setBackground(accentColour);
        btnOpen.setForeground(Color.WHITE);
        btnOpen.setFocusPainted(false);
        btnOpen.setBorderPainted(false);
        btnOpen.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnOpen.setAlignmentX(LEFT_ALIGNMENT);
        btnOpen.addActionListener(onOpen);

        // Hover effect (when the mouse pointing to the open button, it will bright) 
        Color hoverColour = accentColour.brighter();
        btnOpen.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnOpen.setBackground(hoverColour); }
            public void mouseExited(MouseEvent e)  { btnOpen.setBackground(accentColour); }
        });

        card.add(lblTag);
        card.add(Box.createVerticalStrut(4));
        card.add(lblTitle);
        card.add(Box.createVerticalStrut(8));
        card.add(sep);
        card.add(Box.createVerticalStrut(10));
        card.add(lblDesc);
        card.add(Box.createVerticalGlue());
        card.add(Box.createVerticalStrut(14));
        card.add(btnOpen);

        return card;
    }

    //Footer
    private JPanel buildFooter() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBackground(BG_DARK);
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BG_CARD));

        JLabel lbl = new JLabel("All modules connected to  db_skincare  •  OODI Group Project");
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lbl.setForeground(TEXT_GREY);
        footer.add(lbl);
        return footer;
    }

    //The action of DB status check
    private void checkDatabaseConnection() {
        // Run in background so UI doesn't freeze
        new SwingWorker<Boolean, Void>() {
            protected Boolean doInBackground() throws SQLException {
                Connection conn = DatabaseConnection.getConnection();
                return (conn != null);
            }
            protected void done() {
                try {
                    boolean ok = get();
                    if (ok) {
                        lblDbStatus.setText("db_skincare  connected");
                        lblDbStatus.setForeground(ACCENT_GREEN);
                    } else {
                        lblDbStatus.setText("DB not connected — start XAMPP");
                        lblDbStatus.setForeground(ACCENT_PINK);
                    }
                } catch (Exception ignored) {
                    lblDbStatus.setText("DB error");
                    lblDbStatus.setForeground(ACCENT_PINK);
                }
            }
        }.execute();
    }

    //Module launchers

    //Module 1: Product Management
    private void openModule1() {
        ProductManagement frame = new ProductManagement();
        frame.setVisible(true);
    }

    // Module 2: Supplier Management
    private void openModule2() {
        SupplierManagement frame = new SupplierManagement();
        frame.setVisible(true);
    }

    //Module 3: Sales & Point of Sale
    private void openModule3() {
        SalesPOS frame = new SalesPOS();
        frame.setVisible(true);
    }

    //Module 4: Reporting & Analytics
    private void openModule4() {
        ReportUserInterface frame = new ReportUserInterface();
        frame.setVisible(true);
    }

    //Entry point (autogenerated)
    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}

        //SetVisible is to ensure the frame can be displayed
        SwingUtilities.invokeLater(() -> new MainDashboard().setVisible(true));
    }
}
