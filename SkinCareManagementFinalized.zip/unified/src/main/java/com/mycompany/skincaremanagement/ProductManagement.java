package com.mycompany.skincaremanagement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ProductManagement extends JFrame {
    private static final Color BG_DARK      = new Color(24, 24, 36);
    private static final Color BG_CARD      = new Color(36, 36, 54);
    private static final Color ACCENT_PINK  = new Color(230, 100, 140);
    private static final Color TEXT_WHITE   = new Color(240, 240, 250);
    private static final Color TEXT_GREY    = new Color(160, 160, 180);

    private JTextField txtId, txtName, txtBrand, txtCategory, txtSkinType, txtPrice, txtStock;
    private JTable table;
    private DefaultTableModel model;

    public ProductManagement() {
        setTitle("📦 Product Management Module");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout(15, 15));

        // Form inputs panel
        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        inputPanel.setBackground(BG_CARD);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        inputPanel.add(createLabel("Product ID:"));     txtId = createTextField(); inputPanel.add(txtId);
        inputPanel.add(createLabel("Product Name:"));   txtName = createTextField(); inputPanel.add(txtName);
        inputPanel.add(createLabel("Brand:"));          txtBrand = createTextField(); inputPanel.add(txtBrand);
        inputPanel.add(createLabel("Category:"));       txtCategory = createTextField(); inputPanel.add(txtCategory);
        inputPanel.add(createLabel("Skin Type:"));      txtSkinType = createTextField(); inputPanel.add(txtSkinType);
        inputPanel.add(createLabel("Price ($):"));       txtPrice = createTextField(); inputPanel.add(txtPrice);
        inputPanel.add(createLabel("Stock Qty:"));      txtStock = createTextField(); inputPanel.add(txtStock);

        // Control Actions Panel
        JPanel btnPanel = new JPanel(new FlowLayout());
        btnPanel.setBackground(BG_DARK);
        
        JButton btnAdd = createButton("Add Product");
        JButton btnUpdate = createButton("Update");
        JButton btnDelete = createButton("Delete");
        JButton btnRefresh = createButton("Refresh Table");

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnRefresh);

        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(BG_DARK);
        leftPanel.add(inputPanel, BorderLayout.CENTER);
        leftPanel.add(btnPanel, BorderLayout.SOUTH);

        // Table definition
        String[] columns = {"ID", "Name", "Brand", "Category", "Skin Type", "Price", "Stock"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setBackground(BG_CARD);
        table.setForeground(TEXT_WHITE);
        table.setGridColor(BG_DARK);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(BG_DARK);

        add(leftPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        // Event listeners
        btnRefresh.addActionListener(e -> loadData());
        btnAdd.addActionListener(e -> executeDataAction("INSERT INTO product VALUES(?,?,?,?,?,?,?)", true));
        btnUpdate.addActionListener(e -> executeDataAction("UPDATE product SET product_name=?, brand=?, category=?, skin_type=?, price=?, stock=? WHERE product_id=?", false));
        btnDelete.addActionListener(e -> deleteProduct());
        
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = table.getSelectedRow();
                txtId.setText(model.getValueAt(row, 0).toString());
                txtName.setText(model.getValueAt(row, 1).toString());
                txtBrand.setText(model.getValueAt(row, 2).toString());
                txtCategory.setText(model.getValueAt(row, 3).toString());
                txtSkinType.setText(model.getValueAt(row, 4).toString());
                txtPrice.setText(model.getValueAt(row, 5).toString());
                txtStock.setText(model.getValueAt(row, 6).toString());
            }
        });

        loadData();
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(TEXT_WHITE);
        return lbl;
    }

    private JTextField createTextField() {
        JTextField tf = new JTextField();
        tf.setBackground(BG_DARK);
        tf.setForeground(TEXT_WHITE);
        tf.setCaretColor(TEXT_WHITE);
        tf.setBorder(BorderFactory.createLineBorder(TEXT_GREY, 1));
        return tf;
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(ACCENT_PINK);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM product")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("product_id"), rs.getString("product_name"),
                        rs.getString("brand"), rs.getString("category"),
                        rs.getString("skin_type"), rs.getDouble("price"),
                        rs.getInt("stock")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching data: " + ex.getMessage());
        }
    }

    private void executeDataAction(String query, boolean isInsert) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            if (isInsert) {
                pstmt.setString(1, txtId.getText());
                pstmt.setString(2, txtName.getText());
                pstmt.setString(3, txtBrand.getText());
                pstmt.setString(4, txtCategory.getText());
                pstmt.setString(5, txtSkinType.getText());
                pstmt.setDouble(6, Double.parseDouble(txtPrice.getText()));
                pstmt.setInt(7, Integer.parseInt(txtStock.getText()));
            } else {
                pstmt.setString(1, txtName.getText());
                pstmt.setString(2, txtBrand.getText());
                pstmt.setString(3, txtCategory.getText());
                pstmt.setString(4, txtSkinType.getText());
                pstmt.setDouble(5, Double.parseDouble(txtPrice.getText()));
                pstmt.setInt(6, Integer.parseInt(txtStock.getText()));
                pstmt.setString(7, txtId.getText());
            }
            pstmt.executeUpdate();
            loadData();
            clearFields();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Action Failed: " + ex.getMessage());
        }
    }

    private void deleteProduct() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM product WHERE product_id=?")) {
            pstmt.setString(1, txtId.getText());
            pstmt.executeUpdate();
            loadData();
            clearFields();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting item: " + ex.getMessage());
        }
    }

    private void clearFields() {
        txtId.setText(""); txtName.setText(""); txtBrand.setText("");
        txtCategory.setText(""); txtSkinType.setText(""); txtPrice.setText(""); txtStock.setText("");
    }
}